(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_610e0816._.js",
  "static/chunks/node_modules_7f7be971._.js"
],
    source: "dynamic"
});
